package controllers


import "fmt"

func init() {
	
 	fmt.Println("controllers init2 start....")
	
}

