// GENERATED CODE - DO NOT EDIT
package routes

import "github.com/revel/revel"


type tBaseController struct {}
var BaseController tBaseController



type tApp struct {}
var App tApp


func (_ tApp) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Index", args).Url
}


type tStatic struct {}
var Static tStatic


func (_ tStatic) Serve(
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.Serve", args).Url
}

func (_ tStatic) ServeModule(
		moduleName string,
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "moduleName", moduleName)
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.ServeModule", args).Url
}


type tIndex struct {}
var Index tIndex


func (_ tIndex) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.Index", args).Url
}

func (_ tIndex) SdkCooperate(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.SdkCooperate", args).Url
}

func (_ tIndex) SdkApply(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.SdkApply", args).Url
}

func (_ tIndex) MobileIndex(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.MobileIndex", args).Url
}

func (_ tIndex) MobileVote(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.MobileVote", args).Url
}

func (_ tIndex) MobileRule(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.MobileRule", args).Url
}

func (_ tIndex) MobileLaPiao(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.MobileLaPiao", args).Url
}

func (_ tIndex) ZiyouAd(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.ZiyouAd", args).Url
}

func (_ tIndex) ZiyouAdSubmit(
		imgUrl string,
		teamName string,
		teamLeaderQQ string,
		teamLeaderTel string,
		gameServerName string,
		teamLeaderHonor string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "imgUrl", imgUrl)
	revel.Unbind(args, "teamName", teamName)
	revel.Unbind(args, "teamLeaderQQ", teamLeaderQQ)
	revel.Unbind(args, "teamLeaderTel", teamLeaderTel)
	revel.Unbind(args, "gameServerName", gameServerName)
	revel.Unbind(args, "teamLeaderHonor", teamLeaderHonor)
	return revel.MainRouter.Reverse("Index.ZiyouAdSubmit", args).Url
}

func (_ tIndex) MobileZiYouAd(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.MobileZiYouAd", args).Url
}

func (_ tIndex) MobileZiYouSign(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Index.MobileZiYouSign", args).Url
}


