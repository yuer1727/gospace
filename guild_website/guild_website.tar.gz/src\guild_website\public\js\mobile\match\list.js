$(document).ready(function(){
	var ajaxList = initLoad;
	ajaxList()
});