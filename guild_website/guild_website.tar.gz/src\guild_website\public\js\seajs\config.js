seajs.config({

  alias: {
    'jquery':'/public/js/mobile/jquery.js'
  }
  
  
});