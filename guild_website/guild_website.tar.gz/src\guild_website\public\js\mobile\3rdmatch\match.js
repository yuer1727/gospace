/**
 * Created by Administrator on 2016/3/21.
 */



define(function(require,exports, module) {
    require('../module/pullReload.js');  // 下拉刷新页面

});



