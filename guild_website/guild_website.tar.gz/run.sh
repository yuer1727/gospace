#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/guild_website.exe" -importPath guild_website -srcPath "$SCRIPTPATH/src" -runMode prod
